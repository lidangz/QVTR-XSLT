
Solution for Hello World case study  of the Transformation Tool Contest (TTC) 2011 by QVTR-XSLT tool


1. Introduction

This package contains all files for the Hello World case study  of the TTC  2011.

2. What are the files 

The following files  and directories are included:

-- TTC-HelloWorld.xml  :  The transformation model, contains all metamodel and transformation definitions. 
-- QVTR_Profile.mdzip:  The QVTR UML profile for the QVTR-XSLT tool. 
-- QVTRelation Diagram descriptor.xml : The toolbar definition file for the QVTR editor 
-- transformations : contails all generated XSLT stylesheets for all transformations.
-- test-examples : the examples from the case specfication
-- test-results: the results of the transformations.
